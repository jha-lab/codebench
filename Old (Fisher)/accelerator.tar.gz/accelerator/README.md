# accelerator
NN accelerator

batch normalization reference: https://wiseodd.github.io/techblog/2016/07/04/batchnorm/
